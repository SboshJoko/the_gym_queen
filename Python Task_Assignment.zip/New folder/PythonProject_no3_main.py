my_string = "Live happily"
for index, char in enumerate(my_string):
    print("Current character", char, "position at", index )
i=10
while i<=11:
    i+=1
    print("i is out of range")
    if 1==0:
        print("Empty String")
i+=1
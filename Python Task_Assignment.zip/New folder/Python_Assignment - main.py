for number in range(1, 7):
    print(number, number**2)







b="Jumbo"
print(len(b))
print("Power Learn Project (PLP)")

